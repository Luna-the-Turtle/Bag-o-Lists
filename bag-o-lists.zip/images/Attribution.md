All images for usage examples were obtained from pixabay as free-use images with no royalty requirements. A list of all links for images is documented below for reference. 

## Factions
https://pixabay.com/photos/witchcraft-the-wizard-magic-4893559/
https://pixabay.com/vectors/robe-cape-clothing-gown-155409/
https://pixabay.com/illustrations/ai-generated-dragon-black-dragon-9219458/
https://pixabay.com/illustrations/golem-stone-rock-statue-giant-8738112/

## Ammunition
https://pixabay.com/vectors/arc-archery-arco-arrow-quiver-2026927/
https://pixabay.com/vectors/bomb-grenade-explosion-weapon-4757693/
https://pixabay.com/vectors/poison-toxic-bottle-liquid-green-146494/

## NPCs
https://pixabay.com/vectors/woman-girl-amazon-aim-archer-156849/
https://pixabay.com/vectors/vampire-vampiric-witch-gothic-5431457/
https://pixabay.com/vectors/person-fantasy-magic-mask-157130/